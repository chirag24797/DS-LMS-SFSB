/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LMSs;

import javax.ejb.Local;

/**
 *
 * @author chira
 */
@Local
public interface LMSsLocal {
    
    public String issueBook(String bookName,int amount);
            
    public String returnBook(String bookName,int amount);
            
    public String displayBook(int i);
    
}
